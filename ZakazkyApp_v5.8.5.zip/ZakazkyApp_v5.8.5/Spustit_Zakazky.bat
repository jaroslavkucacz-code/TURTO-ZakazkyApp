@echo off
cd /d "%~dp0"
start "" pyw ZakazkyCRM.pyw
