"""TURTO CRM 7.6.11 - Nevoga / Reinforcement Systems exact rich descriptions.

Technical dimensions stay inside one product-description string. The existing
`details_rich_json` text field stores presentation metadata only (which fragments
were red/bold in the supplier PDF); no supplier-specific geometry columns are
added to the CRM schema.
"""
from __future__ import annotations

import json


def _is_nevoga_name(value):
    folded = str(value or "").strip().casefold()
    return any(token in folded for token in ("nevoga", "nevegar", "reinforcement systems"))


def _normalized_segments(raw_segments):
    result = []
    for segment in raw_segments or ():
        if not isinstance(segment, dict):
            continue
        text = str(segment.get("text") or "")
        if not text:
            continue
        color = str(segment.get("color") or "").strip()
        changed = bool(segment.get("changed")) or color.upper() in {
            "#FF0000", "FF0000", "#C62828", "C62828",
        }
        current = {
            "text": text,
            "bold": bool(segment.get("bold")),
            "color": "#FF0000" if changed else color,
            "changed": changed,
        }
        if (
            result
            and result[-1]["bold"] == current["bold"]
            and result[-1]["color"] == current["color"]
            and result[-1]["changed"] == current["changed"]
        ):
            result[-1]["text"] += current["text"]
        else:
            result.append(current)
    return result


def _decode_segments(raw):
    try:
        value = json.loads(str(raw or ""))
    except Exception:
        return []
    return _normalized_segments(value if isinstance(value, list) else [])


def _has_supplier_change(raw):
    return any(segment.get("changed") for segment in _decode_segments(raw))


def apply(M):
    if getattr(M, "_turto_v769_nevoga_offer", False):
        return
    M._turto_v769_nevoga_offer = True

    previous_ensure_schema = M.ensure_schema

    def ensure_schema():
        result = previous_ensure_schema()
        with M.db() as con:
            columns = {
                str(row[1])
                for row in con.execute("PRAGMA table_info(supplier_offer_items)")
            }
            if "details_rich_json" not in columns:
                con.execute(
                    "ALTER TABLE supplier_offer_items "
                    "ADD COLUMN details_rich_json TEXT DEFAULT ''"
                )
        return result

    M.ensure_schema = ensure_schema
    try:
        ensure_schema()
    except Exception:
        pass

    def store_rich_descriptions(offer_id, parsed):
        parsed_items = list((parsed or {}).get("items") or [])
        expected = [
            item for item in parsed_items
            if _normalized_segments(item.get("rich_segments") or [])
        ]
        if not expected:
            return 0

        with M.db() as con:
            columns = {
                str(row[1])
                for row in con.execute("PRAGMA table_info(supplier_offer_items)")
            }
            if "details_rich_json" not in columns:
                con.execute(
                    "ALTER TABLE supplier_offer_items "
                    "ADD COLUMN details_rich_json TEXT DEFAULT ''"
                )

            rows = con.execute(
                "SELECT id,position FROM supplier_offer_items "
                "WHERE offer_id=? ORDER BY position,id",
                (int(offer_id),),
            ).fetchall()
            by_position = {}
            for row in rows:
                by_position.setdefault(int(row["position"] or 0), []).append(int(row["id"]))

            stored = 0
            for item in parsed_items:
                segments = _normalized_segments(item.get("rich_segments") or [])
                if not segments:
                    continue
                position = int(item.get("position") or 0)
                candidates = by_position.get(position) or []
                if not candidates:
                    continue
                item_id = candidates.pop(0)
                con.execute(
                    "UPDATE supplier_offer_items SET details_rich_json=? WHERE id=?",
                    (
                        json.dumps(segments, ensure_ascii=False, separators=(",", ":")),
                        item_id,
                    ),
                )
                stored += 1
        return stored

    M.store_offer_rich_descriptions = store_rich_descriptions

    previous_save_offer_import = M.save_offer_import

    def save_offer_import(*args, **kwargs):
        result = previous_save_offer_import(*args, **kwargs)
        try:
            offer_id = int(result[0])
            parsed = result[3] if len(result) > 3 else {}
            supplier_before = str((parsed or {}).get("supplier") or "")

            if _is_nevoga_name(supplier_before):
                parsed["supplier"] = "Nevoga"
                with M.db() as con:
                    company_id = None
                    resolver = getattr(M, "_company_id_by_name", None)
                    if callable(resolver):
                        try:
                            company_id = resolver(con, "Nevoga")
                        except Exception:
                            company_id = None
                    if company_id:
                        con.execute(
                            "UPDATE supplier_offers SET supplier_name='Nevoga', "
                            "supplier_company_id=coalesce(supplier_company_id,?) WHERE id=?",
                            (company_id, offer_id),
                        )
                    else:
                        con.execute(
                            "UPDATE supplier_offers SET supplier_name='Nevoga' WHERE id=?",
                            (offer_id,),
                        )

            expected = sum(
                1
                for item in list((parsed or {}).get("items") or [])
                if _normalized_segments(item.get("rich_segments") or [])
            )
            if expected:
                stored = store_rich_descriptions(offer_id, parsed)
                if _is_nevoga_name(parsed.get("supplier")) and stored != expected:
                    raise RuntimeError(
                        "Nepodařilo se zachovat červené/formátované části "
                        "popisu nabídky Nevoga. Import nebyl označen za kompletní."
                    )
        except RuntimeError:
            raise
        except Exception:
            pass
        return result

    M.save_offer_import = save_offer_import

    try:
        import crm_features
    except Exception:
        crm_features = None

    candidates = []
    for cls in (
        getattr(crm_features, "OfferDetailDialog", None) if crm_features else None,
        getattr(M, "OfferDetailDialog", None),
    ):
        if cls is not None and cls not in candidates:
            candidates.append(cls)

    for cls in candidates:
        if getattr(cls, "_turto_v769_nevoga_detail", False):
            continue
        previous_build = cls._build

        def build(self, *args, __previous=previous_build, **kwargs):
            result = __previous(self, *args, **kwargs)
            try:
                offer = getattr(self, "offer_row", None)
                supplier = (offer["supplier"] if offer is not None else "") or ""
                if not _is_nevoga_name(supplier):
                    return result
                tree = getattr(self, "tree", None)
                if tree is None:
                    return result

                try:
                    tree.heading("Původní název", text="Popis výrobku")
                except Exception:
                    pass

                # Older export layers bind their button command to a local
                # closure before Nevoga is installed. Rewire only this Nevoga
                # detail so the visible command resolves the current final
                # supplier-aware exporter at click time.
                def rewire_export_buttons(widget):
                    for child in widget.winfo_children():
                        try:
                            text = str(child.cget("text") or "").strip()
                        except Exception:
                            text = ""
                        if text in {
                            "Exportovat do Excelu",
                            "Extrakce dat do Excelu",
                            "Extrakce dat vybrané nabídky",
                        }:
                            try:
                                child.configure(
                                    text="Extrakce dat do Excelu",
                                    command=lambda current=self: M.export_offer_excel(
                                        current.parent_app,
                                        current.oid,
                                        parent=current,
                                    ),
                                )
                            except Exception:
                                pass
                        try:
                            rewire_export_buttons(child)
                        except Exception:
                            pass

                try:
                    rewire_export_buttons(self.f)
                except Exception:
                    pass

                with M.db() as con:
                    rows = con.execute(
                        "SELECT id,details_rich_json FROM supplier_offer_items "
                        "WHERE offer_id=?",
                        (int(self.oid),),
                    ).fetchall()
                rich_by_iid = {
                    f"i{row['id']}": _decode_segments(row["details_rich_json"])
                    for row in rows
                }

                # Never colour an entire table row merely because one supplier
                # value changed. That would overstate what was red in the PDF.
                for iid in tree.get_children(""):
                    tags = [
                        tag for tag in (tree.item(iid, "tags") or ())
                        if tag != "supplier_changed"
                    ]
                    tree.item(iid, tags=tuple(tags))

                existing_children = list(self.f.winfo_children())
                before_widget = existing_children[-1] if existing_children else None
                preview = M.ttk.Frame(self.f, style="Card.TFrame", padding=8)
                M.ttk.Label(
                    preview,
                    text="Popis výrobku – červeně pouze změna z nabídky výrobce",
                    style="PageSubtitle.TLabel",
                ).pack(anchor="w", pady=(0, 3))
                rich_text = M.tk.Text(
                    preview,
                    height=2,
                    wrap="word",
                    font=("Calibri", 10),
                    borderwidth=0,
                    relief="flat",
                    padx=4,
                    pady=4,
                )
                rich_text.pack(fill="x", expand=True)
                rich_text.tag_configure("normal", font=("Calibri", 10))
                rich_text.tag_configure("bold", font=("Calibri", 10, "bold"))
                rich_text.tag_configure("red", foreground="#C62828", font=("Calibri", 10))
                rich_text.tag_configure(
                    "red_bold", foreground="#C62828", font=("Calibri", 10, "bold")
                )
                rich_text.configure(state="disabled")

                def render_exact_description(_event=None):
                    selection = tuple(tree.selection())
                    iid = selection[0] if selection else ""
                    segments = rich_by_iid.get(iid) or []
                    rich_text.configure(state="normal")
                    rich_text.delete("1.0", "end")
                    for segment in segments:
                        changed = bool(segment.get("changed"))
                        bold = bool(segment.get("bold"))
                        tag = (
                            "red_bold" if changed and bold
                            else "red" if changed
                            else "bold" if bold
                            else "normal"
                        )
                        rich_text.insert("end", segment.get("text") or "", tag)
                    rich_text.configure(state="disabled")

                tree.bind("<<TreeviewSelect>>", render_exact_description, add="+")
                try:
                    if before_widget is not None:
                        preview.pack(fill="x", pady=(6, 0), before=before_widget)
                    else:
                        preview.pack(fill="x", pady=(6, 0))
                except Exception:
                    preview.pack(fill="x", pady=(6, 0))

                selection = tuple(tree.selection())
                if not selection:
                    first = tree.get_children("")
                    if first:
                        tree.selection_set(first[0])
                render_exact_description()
            except Exception:
                pass
            return result

        cls._build = build
        cls._turto_v769_nevoga_detail = True

    previous_export_offer_excel = getattr(M, "export_offer_excel", None)

    def export_offer_excel(app, offer_id, parent=None):
        with M.db() as con:
            offer = con.execute(
                """SELECT o.*,
                          coalesce(nullif(trim(s.official_name),''),
                                   nullif(trim(s.short_name),''),
                                   nullif(trim(o.supplier_name),''),'') supplier
                   FROM supplier_offers o
                   LEFT JOIN companies s ON s.id=o.supplier_company_id
                   WHERE o.id=?""",
                (int(offer_id),),
            ).fetchone()
        if not offer or not _is_nevoga_name(offer["supplier"]):
            if callable(previous_export_offer_excel):
                return previous_export_offer_excel(app, offer_id, parent=parent)
            return None

        from tkinter import filedialog, messagebox

        initial = (
            M.offer_export_filename(offer_id)
            if callable(getattr(M, "offer_export_filename", None))
            else f"Extrakce dat CN {offer['offer_number'] or 'nabidka'}.xlsx"
        )
        path = filedialog.asksaveasfilename(
            parent=parent or app,
            title="Extrakce dat nabídky",
            defaultextension=".xlsx",
            filetypes=[("Excel", "*.xlsx")],
            initialfile=initial,
        )
        if not path:
            return None

        try:
            with M.db() as con:
                items = con.execute(
                    "SELECT * FROM supplier_offer_items "
                    "WHERE offer_id=? ORDER BY position,id",
                    (int(offer_id),),
                ).fetchall()

            parsed_items = []
            for item in items:
                parsed_items.append(
                    {
                        "position": item["position"],
                        "product": item["product_code"] or "",
                        "description": item["original_name"] or item["item_key"] or "",
                        "item_key": item["item_key"] or item["original_name"] or "",
                        "details": item["details"] or "",
                        "rich_segments": _decode_segments(item["details_rich_json"]),
                        "quantity": item["quantity"] or 0,
                        "unit": item["unit"] or "ks",
                        "original_unit_price": item["original_unit_price"] or item["unit_price"] or 0,
                        "discount_pct": item["discount_pct"] or 0,
                        "unit_price": item["unit_price"] or 0,
                        "item_total": item["total_price"] or 0,
                        "image_bytes": bytes(item["image_blob"]) if item["image_blob"] else None,
                        "image_ext": item["image_ext"] or "png",
                    }
                )

            router = M._load_offer_router()
            provider = next(
                (
                    entry for entry in router.parsers()
                    if _is_nevoga_name(entry.get("supplier"))
                ),
                None,
            )
            if not provider or not callable(provider.get("export")):
                raise RuntimeError("Chybí Excel export pro nabídky Nevoga.")

            data = {
                "supplier": "Nevoga",
                "offer_no": offer["offer_number"] or "",
                "date": offer["offer_date"] or "",
                "reference": offer["reference"] or "",
                "net": float(offer["net_value"] or offer["total_value"] or 0),
                "total": float(offer["total_value"] or offer["net_value"] or 0),
                "currency": offer["currency"] or "CZK",
                "items": parsed_items,
            }
            provider["export"](data, path, price_alerts=None)
            messagebox.showinfo(
                "Extrakce dat",
                f"Extrakce vytvořena:\n{path}",
                parent=parent or app,
            )
            return path
        except Exception as exc:
            messagebox.showerror(
                "Extrakce dat",
                str(exc),
                parent=parent or app,
            )
            return None

    if callable(previous_export_offer_excel):
        M.export_offer_excel = export_offer_excel

        # The main Offers command is also captured by older layers. Replace the
        # final method here so selecting a Nevoga offer always reaches the
        # supplier-aware exporter above; non-Nevoga offers still delegate to
        # the previous exporter from inside export_offer_excel().
        def export_selected_offer_excel(self):
            offer_id = (
                self._selected_offer_id()
                if hasattr(self, "_selected_offer_id")
                else None
            )
            if not offer_id:
                return M.messagebox.showinfo(
                    "Extrakce dat",
                    "Vyberte nabídku.",
                    parent=self,
                )
            return M.export_offer_excel(self, offer_id, parent=self)

        M.App.export_selected_offer_excel = export_selected_offer_excel

    M.V769_NEVOGA_RICH_DESCRIPTION = {
        "technical_columns_added": False,
        "description_owner": "supplier_offer_items.original_name",
        "rich_format_owner": "supplier_offer_items.details_rich_json",
        "supplier_red_preserved": True,
        "excel_partial_red": True,
        "detail_changed_rows_red": False,
        "detail_exact_rich_preview": True,
        "excel_description_columns": 4,
        "excel_image_columns": 2,
    }
