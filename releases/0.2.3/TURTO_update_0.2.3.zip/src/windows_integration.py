from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path


def _vbs_quote(value: str) -> str:
    return str(value).replace('"', '""')


def _pythonw_executable() -> Path:
    exe = Path(sys.executable)
    if exe.name.lower() == 'python.exe':
        candidate = exe.with_name('pythonw.exe')
        if candidate.exists():
            return candidate
    return exe


def ensure_windows_shortcuts(root: str | Path) -> None:
    """Create/update TURTO shortcuts on Windows using only built-in WSH.

    This is best-effort and deliberately silent. The running window itself
    gets its taskbar icon independently through AppUserModelID + Tk iconphoto.
    """
    if sys.platform != 'win32':
        return

    root = Path(root).resolve()
    icon = root / 'assets' / 'app_icon.ico'
    app = root / 'app.pyw'
    if not icon.exists() or not app.exists():
        return

    exe = _pythonw_executable().resolve()
    lines = [
        'Set shell = CreateObject("WScript.Shell")',
        'desktop = shell.SpecialFolders("Desktop")',
        f'root = "{_vbs_quote(str(root))}"',
        f'target = "{_vbs_quote(str(exe))}"',
        f'args = Chr(34) & "{_vbs_quote(str(app))}" & Chr(34)',
        f'icon = "{_vbs_quote(str(icon))},0"',
        'For Each linkPath In Array(desktop & "\\TURTO - Mesicni prehledy.lnk", root & "\\TURTO - Mesicni prehledy.lnk")',
        '  Set sc = shell.CreateShortcut(linkPath)',
        '  sc.TargetPath = target',
        '  sc.Arguments = args',
        '  sc.WorkingDirectory = root',
        '  sc.IconLocation = icon',
        '  sc.Description = "TURTO - Mesicni prehledy"',
        '  sc.Save',
        'Next',
    ]
    script = '\r\n'.join(lines) + '\r\n'

    tmp = None
    try:
        fd, name = tempfile.mkstemp(prefix='turto_shortcut_', suffix='.vbs')
        os.close(fd)
        tmp = Path(name)
        tmp.write_text(script, encoding='utf-8-sig')
        flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
        subprocess.run(
            ['cscript.exe', '//nologo', str(tmp)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=8,
            check=False,
            creationflags=flags,
        )
    finally:
        if tmp:
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass
