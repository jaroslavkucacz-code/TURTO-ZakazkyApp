from __future__ import annotations

import ctypes
import os
import subprocess
import sys
import tempfile
from pathlib import Path


def _vbs_quote(value: str) -> str:
    return str(value).replace('"', '""')


def _pythonw_executable() -> Path:
    exe = Path(sys.executable)
    if exe.name.lower() == 'python.exe':
        candidate = exe.with_name('pythonw.exe')
        if candidate.exists():
            return candidate
    return exe


def apply_native_window_icon(window, root: str | Path) -> None:
    """Apply TURTO icons to the actual native top-level Windows window.

    Tk creates an inner child HWND and a separate wrapper HWND that owns the
    non-client frame. The wrapper can be created/recreated while the window
    is mapped or maximized, so targeting only ``winfo_id()`` is not reliable.
    This routine resolves the GA_ROOT ancestor and applies both window and
    class icons to every relevant HWND.
    """
    if sys.platform != 'win32':
        return
    icon = Path(root).resolve() / 'assets' / 'app_icon.ico'
    if not icon.exists():
        return
    try:
        from ctypes import wintypes
        user32 = ctypes.windll.user32

        LoadImageW = user32.LoadImageW
        LoadImageW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT,
                               ctypes.c_int, ctypes.c_int, wintypes.UINT]
        LoadImageW.restype = wintypes.HANDLE
        SendMessageW = user32.SendMessageW
        SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        SendMessageW.restype = ctypes.c_ssize_t
        GetParent = user32.GetParent
        GetParent.argtypes = [wintypes.HWND]
        GetParent.restype = wintypes.HWND
        GetAncestor = user32.GetAncestor
        GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
        GetAncestor.restype = wintypes.HWND

        if ctypes.sizeof(ctypes.c_void_p) == 8:
            SetClassLongPtrW = user32.SetClassLongPtrW
            SetClassLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t]
            SetClassLongPtrW.restype = ctypes.c_ssize_t
        else:
            SetClassLongPtrW = user32.SetClassLongW
            SetClassLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int, wintypes.LONG]
            SetClassLongPtrW.restype = wintypes.LONG

        window.update_idletasks()
        child = wintypes.HWND(window.winfo_id())
        GA_ROOT = 2
        root_hwnd = GetAncestor(child, GA_ROOT)

        hwnds = []
        def add_hwnd(h):
            if h:
                value = int(h)
                if value and value not in hwnds:
                    hwnds.append(value)

        add_hwnd(child)
        add_hwnd(root_hwnd)
        cur = child
        for _ in range(8):
            cur = GetParent(cur)
            if not cur:
                break
            add_hwnd(cur)

        IMAGE_ICON = 1
        LR_LOADFROMFILE = 0x0010
        WM_SETICON = 0x0080
        ICON_SMALL = 0
        ICON_BIG = 1
        GCLP_HICON = -14
        GCLP_HICONSM = -34
        smx = user32.GetSystemMetrics(49) or 16
        smy = user32.GetSystemMetrics(50) or 16
        bigx = user32.GetSystemMetrics(11) or 32
        bigy = user32.GetSystemMetrics(12) or 32

        small = LoadImageW(None, str(icon), IMAGE_ICON, smx, smy, LR_LOADFROMFILE)
        big = LoadImageW(None, str(icon), IMAGE_ICON, bigx, bigy, LR_LOADFROMFILE)
        handles = [h for h in (small, big) if h]

        for value in hwnds:
            hwnd = wintypes.HWND(value)
            if small:
                SendMessageW(hwnd, WM_SETICON, ICON_SMALL, int(small))
                try:
                    SetClassLongPtrW(hwnd, GCLP_HICONSM, int(small))
                except Exception:
                    pass
            if big:
                SendMessageW(hwnd, WM_SETICON, ICON_BIG, int(big))
                try:
                    SetClassLongPtrW(hwnd, GCLP_HICON, int(big))
                except Exception:
                    pass

        old = getattr(window, '_turto_native_icon_handles', [])
        window._turto_native_icon_handles = old + handles
    except Exception:
        pass


def install_native_icon_refresh(window, root: str | Path) -> None:
    """Re-apply the native icon after Tk/Windows finishes mapping the frame."""
    if sys.platform != 'win32':
        return
    root = Path(root).resolve()

    def refresh(_event=None):
        try:
            window.after_idle(lambda: apply_native_window_icon(window, root))
        except Exception:
            pass

    try:
        window.bind('<Map>', refresh, add='+')
    except Exception:
        pass
    for delay in (0, 80, 250, 700, 1500):
        try:
            window.after(delay, lambda r=root: apply_native_window_icon(window, r))
        except Exception:
            pass


def ensure_windows_shortcuts(root: str | Path) -> None:
    """Create/update TURTO shortcuts on Windows using only built-in WSH."""
    if sys.platform != 'win32':
        return

    root = Path(root).resolve()
    icon = root / 'assets' / 'app_icon.ico'
    app = root / 'app.pyw'
    if not icon.exists() or not app.exists():
        return

    exe = _pythonw_executable().resolve()
    lines = [
        'Set shell = CreateObject("WScript.Shell")',
        'desktop = shell.SpecialFolders("Desktop")',
        f'root = "{_vbs_quote(str(root))}"',
        f'target = "{_vbs_quote(str(exe))}"',
        f'args = Chr(34) & "{_vbs_quote(str(app))}" & Chr(34)',
        f'icon = "{_vbs_quote(str(icon))},0"',
        'For Each linkPath In Array(desktop & "\\TURTO - Mesicni prehledy.lnk", root & "\\TURTO - Mesicni prehledy.lnk")',
        '  Set sc = shell.CreateShortcut(linkPath)',
        '  sc.TargetPath = target',
        '  sc.Arguments = args',
        '  sc.WorkingDirectory = root',
        '  sc.IconLocation = icon',
        '  sc.Description = "TURTO - Mesicni prehledy"',
        '  sc.Save',
        'Next',
    ]
    script = '\r\n'.join(lines) + '\r\n'

    tmp = None
    try:
        fd, name = tempfile.mkstemp(prefix='turto_shortcut_', suffix='.vbs')
        os.close(fd)
        tmp = Path(name)
        tmp.write_text(script, encoding='utf-8-sig')
        flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
        subprocess.run(
            ['cscript.exe', '//nologo', str(tmp)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=8,
            check=False,
            creationflags=flags,
        )
        try:
            subprocess.run(['ie4uinit.exe', '-show'], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=5, check=False,
                           creationflags=flags)
        except Exception:
            pass
    finally:
        if tmp:
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass
