from __future__ import annotations

import ctypes
import os
import subprocess
import sys
import uuid
from contextlib import contextmanager
from pathlib import Path

APP_ID = 'cz.turto.mesicni-prehledy'


def _guid(text: str):
    from ctypes import wintypes
    class GUID(ctypes.Structure):
        _fields_=[('Data1',wintypes.DWORD),('Data2',wintypes.WORD),('Data3',wintypes.WORD),('Data4',ctypes.c_ubyte*8)]
    return GUID.from_buffer_copy(uuid.UUID(text).bytes_le)


@contextmanager
def _com():
    owned=False
    try:
        ole32=ctypes.windll.ole32
        ole32.CoInitializeEx.argtypes=[ctypes.c_void_p,ctypes.c_uint]
        ole32.CoInitializeEx.restype=ctypes.c_long
        hr=int(ole32.CoInitializeEx(None,0x2))
        owned=hr in (0,1)
    except Exception:
        pass
    try:
        yield
    finally:
        if owned:
            try: ctypes.windll.ole32.CoUninitialize()
            except Exception: pass


def _pv_types():
    cached=getattr(_pv_types,'_cached',None)
    if cached is not None:
        return cached
    from ctypes import wintypes
    class GUID(ctypes.Structure):
        _fields_=[('Data1',wintypes.DWORD),('Data2',wintypes.WORD),('Data3',wintypes.WORD),('Data4',ctypes.c_ubyte*8)]
    class PROPERTYKEY(ctypes.Structure):
        _fields_=[('fmtid',GUID),('pid',wintypes.DWORD)]
    class U(ctypes.Union):
        _fields_=[('pwszVal',wintypes.LPWSTR),('ptr',ctypes.c_void_p),('raw',ctypes.c_ubyte*8)]
    class PROPVARIANT(ctypes.Structure):
        _anonymous_=('u',)
        _fields_=[('vt',ctypes.c_ushort),('r1',ctypes.c_ushort),('r2',ctypes.c_ushort),('r3',ctypes.c_ushort),('u',U)]
    cached=(GUID,PROPERTYKEY,PROPVARIANT)
    _pv_types._cached=cached
    return cached


def _key(pid:int):
    GUID,PROPERTYKEY,_=_pv_types()
    fmt=GUID.from_buffer_copy(uuid.UUID('9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3').bytes_le)
    return PROPERTYKEY(fmt,int(pid))


def _pv_string(value:str):
    # Build VT_LPWSTR directly. The backing Unicode buffer must stay alive
    # until IPropertyStore.SetValue returns. Do not PropVariantClear this
    # variant because the string memory is owned by Python, not COM.
    _,_,PROPVARIANT=_pv_types();pv=PROPVARIANT()
    from ctypes import wintypes
    buf=ctypes.create_unicode_buffer(str(value))
    pv.vt=31  # VT_LPWSTR
    pv.pwszVal=ctypes.cast(buf,wintypes.LPWSTR)
    return pv,buf


def _pv_clear(pv):
    try: ctypes.windll.ole32.PropVariantClear(ctypes.byref(pv))
    except Exception: pass


def _vtbl(ptr):
    return ctypes.cast(ptr,ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents


def _release(ptr):
    if not ptr:return
    try: ctypes.WINFUNCTYPE(ctypes.c_ulong,ctypes.c_void_p)(_vtbl(ptr)[2])(ptr)
    except Exception: pass


def _qi(ptr,iid_text:str):
    if not ptr:return ctypes.c_void_p()
    iid=_guid(iid_text);out=ctypes.c_void_p()
    fn=ctypes.WINFUNCTYPE(ctypes.c_long,ctypes.c_void_p,ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p))(_vtbl(ptr)[0])
    return out if int(fn(ptr,ctypes.byref(iid),ctypes.byref(out)))>=0 else ctypes.c_void_p()


def _set_store(store,values)->bool:
    if not store:return False
    _,PROPERTYKEY,PROPVARIANT=_pv_types();v=_vtbl(store)
    setv=ctypes.WINFUNCTYPE(ctypes.c_long,ctypes.c_void_p,ctypes.POINTER(PROPERTYKEY),ctypes.POINTER(PROPVARIANT))(v[6])
    commit=ctypes.WINFUNCTYPE(ctypes.c_long,ctypes.c_void_p)(v[7]);ok=True
    try:
        for pid,value in values:
            pv,buf=_pv_string(value)
            # Keep `buf` alive through SetValue. The PROPVARIANT points into
            # that Python-owned buffer and therefore must not be cleared.
            k=_key(pid)
            if int(setv(store,ctypes.byref(k),ctypes.byref(pv)))<0:ok=False
        if int(commit(store))<0:ok=False
        return ok
    finally:_release(store)


def _get_store_string(store,pid:int)->str:
    if not store:return ''
    _,PROPERTYKEY,PROPVARIANT=_pv_types();v=_vtbl(store)
    getv=ctypes.WINFUNCTYPE(ctypes.c_long,ctypes.c_void_p,ctypes.POINTER(PROPERTYKEY),ctypes.POINTER(PROPVARIANT))(v[5])
    pv=PROPVARIANT()
    try:
        k=_key(pid);hr=int(getv(store,ctypes.byref(k),ctypes.byref(pv)))
        return str(pv.pwszVal) if hr>=0 and pv.vt==31 and pv.pwszVal else ''
    finally:_pv_clear(pv)


def _pythonw()->Path:
    exe=Path(sys.executable)
    if exe.name.lower()=='python.exe' and exe.with_name('pythonw.exe').exists():exe=exe.with_name('pythonw.exe')
    return exe.resolve()


def _top_hwnd(window)->int:
    from ctypes import wintypes
    user32=ctypes.windll.user32
    fn=user32.GetAncestor;fn.argtypes=[wintypes.HWND,wintypes.UINT];fn.restype=wintypes.HWND
    window.update_idletasks();child=wintypes.HWND(window.winfo_id())
    return int(fn(child,2) or child)


def set_window_identity(window,root:Path)->bool:
    if sys.platform!='win32':return False
    from ctypes import wintypes
    root=Path(root).resolve();hwnd=_top_hwnd(window)
    with _com():
        shell32=ctypes.windll.shell32
        getstore=shell32.SHGetPropertyStoreForWindow
        getstore.argtypes=[wintypes.HWND,ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)];getstore.restype=ctypes.c_long
        iid=_guid('886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99');store=ctypes.c_void_p()
        if int(getstore(wintypes.HWND(hwnd),ctypes.byref(iid),ctypes.byref(store)))<0 or not store.value:return False
        app=(root/'app.pyw').resolve();icon=(root/'assets/app_icon.ico').resolve();exe=_pythonw()
        return _set_store(store,[(2,f'"{exe}" "{app}"'),(3,f'{icon},0'),(5,APP_ID)])


def window_app_id(window)->str:
    if sys.platform!='win32':return ''
    from ctypes import wintypes
    hwnd=_top_hwnd(window)
    with _com():
        shell32=ctypes.windll.shell32;fn=shell32.SHGetPropertyStoreForWindow
        fn.argtypes=[wintypes.HWND,ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)];fn.restype=ctypes.c_long
        iid=_guid('886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99');store=ctypes.c_void_p()
        if int(fn(wintypes.HWND(hwnd),ctypes.byref(iid),ctypes.byref(store)))<0:return ''
        try:return _get_store_string(store,5)
        finally:_release(store)


def create_shortcut(path:Path,root:Path)->bool:
    if sys.platform!='win32':return False
    from ctypes import wintypes
    path=Path(path);root=Path(root).resolve();path.parent.mkdir(parents=True,exist_ok=True)
    target=_pythonw();args=f'"{(root/"app.pyw").resolve()}"';icon=(root/'assets/app_icon.ico').resolve()
    with _com():
        link=ctypes.c_void_p()
        try:
            ole32=ctypes.windll.ole32;ole32.CoCreateInstance.argtypes=[ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)];ole32.CoCreateInstance.restype=ctypes.c_long
            clsid=_guid('00021401-0000-0000-C000-000000000046');iid=_guid('000214F9-0000-0000-C000-000000000046')
            if int(ole32.CoCreateInstance(ctypes.byref(clsid),None,1,ctypes.byref(iid),ctypes.byref(link)))<0:return False
            v=_vtbl(link);F=ctypes.WINFUNCTYPE
            if int(F(ctypes.c_long,ctypes.c_void_p,wintypes.LPCWSTR)(v[20])(link,str(target)))<0:return False
            F(ctypes.c_long,ctypes.c_void_p,wintypes.LPCWSTR)(v[11])(link,args)
            F(ctypes.c_long,ctypes.c_void_p,wintypes.LPCWSTR)(v[9])(link,str(root))
            F(ctypes.c_long,ctypes.c_void_p,wintypes.LPCWSTR,ctypes.c_int)(v[17])(link,str(icon),0)
            F(ctypes.c_long,ctypes.c_void_p,wintypes.LPCWSTR)(v[7])(link,'TURTO - Mesicni prehledy')
            store=_qi(link,'886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99')
            if not store.value or not _set_store(store,[(5,APP_ID)]):return False
            persist=_qi(link,'0000010B-0000-0000-C000-000000000046')
            if not persist.value:return False
            try:
                save=F(ctypes.c_long,ctypes.c_void_p,wintypes.LPCWSTR,wintypes.BOOL)(_vtbl(persist)[6])
                return int(save(persist,str(path),True))>=0 and path.exists()
            finally:_release(persist)
        finally:_release(link)


def shortcut_app_id(path:Path)->str:
    if sys.platform!='win32' or not Path(path).exists():return ''
    from ctypes import wintypes
    with _com():
        link=ctypes.c_void_p()
        try:
            ole32=ctypes.windll.ole32;ole32.CoCreateInstance.argtypes=[ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)];ole32.CoCreateInstance.restype=ctypes.c_long
            clsid=_guid('00021401-0000-0000-C000-000000000046');iid=_guid('000214F9-0000-0000-C000-000000000046')
            if int(ole32.CoCreateInstance(ctypes.byref(clsid),None,1,ctypes.byref(iid),ctypes.byref(link)))<0:return ''
            persist=_qi(link,'0000010B-0000-0000-C000-000000000046')
            if not persist.value:return ''
            try:
                load=ctypes.WINFUNCTYPE(ctypes.c_long,ctypes.c_void_p,wintypes.LPCWSTR,wintypes.DWORD)(_vtbl(persist)[5])
                if int(load(persist,str(path),0))<0:return ''
            finally:_release(persist)
            store=_qi(link,'886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99')
            if not store.value:return ''
            try:return _get_store_string(store,5)
            finally:_release(store)
        finally:_release(link)


def ensure_shortcuts(root:Path)->list[Path]:
    if sys.platform!='win32':return []
    root=Path(root).resolve();links=[root/'TURTO - Mesicni prehledy.lnk']
    profile=os.environ.get('USERPROFILE');appdata=os.environ.get('APPDATA')
    if profile:links.append(Path(profile)/'Desktop'/'TURTO - Mesicni prehledy.lnk')
    if appdata:links.append(Path(appdata)/'Microsoft/Windows/Start Menu/Programs/TURTO - Mesicni prehledy.lnk')
    made=[]
    for p in links:
        try:
            if create_shortcut(p,root):made.append(p)
        except Exception:pass
    try:subprocess.run(['ie4uinit.exe','-show'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=5,check=False,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    except Exception:pass
    return made


def _icon_handles(window)->tuple[int,int]:
    if sys.platform!='win32':return (0,0)
    from ctypes import wintypes
    hwnd=_top_hwnd(window);fn=ctypes.windll.user32.SendMessageW
    fn.argtypes=[wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM];fn.restype=ctypes.c_ssize_t
    return int(fn(wintypes.HWND(hwnd),0x007F,0,0) or 0),int(fn(wintypes.HWND(hwnd),0x007F,1,0) or 0)


def write_diagnostic(window,root:Path)->None:
    if sys.platform!='win32':return
    root=Path(root).resolve();shortcut=root/'TURTO - Mesicni prehledy.lnk';small,big=_icon_handles(window)
    process=''
    try:
        ptr=ctypes.c_wchar_p();fn=ctypes.windll.shell32.GetCurrentProcessExplicitAppUserModelID
        fn.argtypes=[ctypes.POINTER(ctypes.c_wchar_p)];fn.restype=ctypes.c_long
        if int(fn(ctypes.byref(ptr)))>=0 and ptr.value:
            process=ptr.value;ctypes.windll.ole32.CoTaskMemFree(ptr)
    except Exception:pass
    lines=[f'process_app_id={process}',f'window_app_id={window_app_id(window)}',f'wm_geticon_small={small}',f'wm_geticon_big={big}',f'shortcut_app_id={shortcut_app_id(shortcut)}',f'shortcut={shortcut}',f'icon={root/"assets/app_icon.ico"}']
    try:(root/'windows_identity.log').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    except Exception:pass


def install_windows_identity(window,root:Path)->None:
    if sys.platform!='win32':return
    root=Path(root).resolve()
    try:ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    except Exception:pass
    ensure_shortcuts(root)
    def apply():
        try:
            from .windows_integration import apply_native_window_icon
            apply_native_window_icon(window,root)
        except Exception:pass
        try:set_window_identity(window,root)
        except Exception:pass
    for ms in (0,100,350,900,1800,3500):
        try:window.after(ms,apply)
        except Exception:pass
    try:window.after(2200,lambda:write_diagnostic(window,root))
    except Exception:pass
