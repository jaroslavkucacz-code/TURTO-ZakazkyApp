"""Responsive Tk charts. No Matplotlib, Pillow or native graphics extensions."""
from __future__ import annotations
import math
import tkinter as tk
from tkinter import font as tkfont
from .constants import COLORS
from .chart_geometry import axis, grouped, series_value, number, money as fmt_money, percent as fmt_pct, count

PALETTE=(COLORS['teal'],COLORS['amber'],COLORS['blue'],'#AB96DF','#D693B3','#96C5A4','#8193A9','#BF9780')
SPECIAL_COLORS={'Milan':COLORS['teal'],'Honza':COLORS['blue'],'Jirka':COLORS['amber'],'Nezařazené':'#8193A9'}
MIN_DONUT_DEGREES=0.5

def _metric_color(key):
    return {'revenue':COLORS['teal'],'profit':COLORS['amber'],'margin':COLORS['blue'],'count':COLORS['blue']}.get(key,COLORS['text'])

def _display_colors(items):
    # Barvy se přidělují jen právě zobrazeným kategoriím. TOP položky tak
    # nemohou dostat stejnou barvu kvůli cyklování palety přes skryté řádky.
    result={};used=set();palette_index=0
    for item in items:
        label=str(item.get('label') or 'Bez názvu')
        if label in SPECIAL_COLORS:
            color=SPECIAL_COLORS[label]
        elif label.startswith('Nezařazené') or label.startswith('Ostatní'):
            color='#8193A9'
        else:
            color=None
            for _ in range(len(PALETTE)):
                candidate=PALETTE[palette_index%len(PALETTE)];palette_index+=1
                if candidate not in used:
                    color=candidate;break
            if color is None:color=PALETTE[palette_index%len(PALETTE)]
        result[label]=color;used.add(color)
    return result


def _fit(font,text,width):
    text=str(text).replace('\n',' ')
    if font.measure(text)<=width:return text
    lo,hi=0,len(text)
    while lo<hi:
        mid=(lo+hi+1)//2
        if font.measure(text[:mid]+'…')<=width:lo=mid
        else:hi=mid-1
    return text[:lo]+'…' if width>font.measure('…') else ''


class _CanvasFrame(tk.Frame):
    def __init__(self,master):
        super().__init__(master,bg=COLORS['panel'])
        self._pending=None
        self._fonts={}
        self.bind('<Destroy>',self._destroyed,add='+')

    def _font(self,size=9,bold=False):
        key=(size,bold)
        if key not in self._fonts:self._fonts[key]=tkfont.Font(self,family='Calibri',size=size,weight='bold' if bold else 'normal')
        return self._fonts[key]

    def _canvas(self,height):
        self.canvas=tk.Canvas(self,bg=COLORS['panel'],highlightthickness=0,bd=0,height=height)
        self.canvas.pack(fill='both',expand=True)
        self.canvas.bind('<Configure>',self._schedule)
        self._schedule()

    def _schedule(self,event=None):
        if self._pending is None:self._pending=self.after_idle(self._scheduled_draw)

    def _scheduled_draw(self):
        self._pending=None
        if self.winfo_exists():self._draw()

    def _destroyed(self,event):
        if event.widget is self and self._pending is not None:
            try:self.after_cancel(self._pending)
            except tk.TclError:pass
            self._pending=None

    def _text(self,x,y,text,*,width=None,size=9,bold=False,color=None,anchor='w',tag='labels'):
        font=self._font(size,bold)
        text=_fit(font,text,width) if width is not None else str(text)
        return self.canvas.create_text(x,y,text=text,font=font,fill=color or COLORS['text'],anchor=anchor,tags=(tag,))

    def _tooltip(self,text,x,y):
        c=self.canvas;c.delete('tooltip');w=c.winfo_width();h=c.winfo_height()
        font=self._font(9)
        width=max(30,min(w-28,max(font.measure(s) for s in text.split('\n'))))
        item=c.create_text(14,10,text=text,anchor='nw',font=font,width=width,fill=COLORS['text'],tags=('tooltip',))
        box=c.bbox(item)
        # Extremely long names must not push a tooltip outside the chart.
        remaining=text
        while box and box[3]-box[1]+18>h-4 and len(remaining)>8:
            remaining=remaining[:max(8,int(len(remaining)*.85))].rstrip()
            c.itemconfigure(item,text=remaining+'…');box=c.bbox(item)
        tw,th=box[2]-box[0]+24,box[3]-box[1]+18
        x=max(2,min(x,w-tw-2));y=max(2,min(y,h-th-2))
        c.move(item,x+12-box[0],y+9-box[1])
        rect=c.create_rectangle(x,y,x+tw,y+th,fill='#0D1524',outline=COLORS['border'],tags=('tooltip',))
        c.tag_lower(rect,item)

    def _notify(self,callback,data):
        if callback:
            try:callback(data)
            except Exception:
                import sys
                self._root().report_callback_exception(*sys.exc_info())


class BusinessChart(_CanvasFrame):
    SERIES=(('revenue','Obrat',COLORS['teal']),('profit','Zisk',COLORS['amber']),('margin','Marže %',COLORS['blue']))

    def __init__(self,master,data,*,subtitle='Částky vlevo · marže na pravé ose',show_mode_switch=True,
                 trim_trailing_empty=False,on_period_click=None,height=290,initial_enabled=('revenue','profit','margin')):
        super().__init__(master)
        self._all_data=[dict(x) for x in data];self._data=self._all_data[:]
        if trim_trailing_empty:
            while self._data and not (self._data[-1].get('has_data') or any((series_value(self._data[-1],k) or 0)!=0 for k in ('revenue','profit'))):self._data.pop()
        self._enabled={k:k in initial_enabled for k,_,_ in self.SERIES}
        if not any(self._enabled.values()):self._enabled['revenue']=True
        self._hover_index=None;self._centers=[];self._plot_bounds=(0,0,0,0);self._on_period_click=on_period_click
        caption=tk.Label(self,text=subtitle,bg=COLORS['panel'],fg=COLORS['muted'],justify='left',anchor='w',font=('Calibri',9))
        caption.pack(fill='x',pady=(0,7))
        caption.bind('<Configure>',lambda e:caption.configure(wraplength=max(40,e.width-4)))
        self._buttons={}
        if show_mode_switch:
            bar=tk.Frame(self,bg=COLORS['panel']);bar.pack(fill='x',pady=(0,6))
            for k,label,color in self.SERIES:
                b=tk.Button(bar,text=label,command=lambda key=k:self.toggle(key),font=('Calibri',9,'bold'),padx=9,pady=5,relief='flat',bd=0)
                b.pack(side='left',padx=(0,5));self._buttons[k]=b
            self._refresh_buttons()
        self._canvas(height)
        self.canvas.bind('<Motion>',self._motion);self.canvas.bind('<Leave>',self._leave);self.canvas.bind('<Button-1>',self._click)

    def _refresh_buttons(self):
        for k,label,color in self.SERIES:
            if k in self._buttons:
                active=self._enabled[k]
                self._buttons[k].configure(text=('✓ ' if active else '')+label,bg=COLORS['panel_alt'] if active else COLORS['panel_soft'],
                    fg=color if active else COLORS['muted'],activebackground=COLORS['border'],activeforeground=COLORS['text'])

    def toggle(self,key):
        if key not in self._enabled:return
        if self._enabled[key] and sum(self._enabled.values())==1:return
        self._enabled[key]=not self._enabled[key];self._hover_index=None;self._refresh_buttons();self._draw()

    def _draw(self,event=None):
        c=self.canvas;c.delete('all');w=c.winfo_width();h=c.winfo_height();self._centers=[]
        if w<150 or h<125:return
        if not self._data:
            self._text(w/2,h/2,'Pro vybrané období nejsou data.',width=w-16,anchor='center',color=COLORS['muted']);return
        mo=self._enabled['revenue'] or self._enabled['profit'];po=self._enabled['margin']
        ma=axis([series_value(r,k) for r in self._data for k in ('revenue','profit') if self._enabled[k]])
        pa=axis([series_value(r,'margin') for r in self._data],True)
        f=self._font(9)
        left=max(56,max(f.measure(ma.label(v)) for v in ma.ticks())+16) if mo else 12
        right=max(68,max(f.measure(pa.label(v)) for v in pa.ticks())+16) if po else 12
        fh=f.metrics('linespace');nh=self._font(8).metrics('linespace')
        top=max(40,fh+18);bottom=h-(2*fh+nh+15);xr=w-right
        if xr-left<75 or bottom-top<40:return
        self._plot_bounds=(left,top,xr,bottom);self._axes=(ma,pa)
        slot=(xr-left)/len(self._data);self._centers=[left+(i+.5)*slot for i in range(len(self._data))]
        if self._hover_index is not None and self._hover_index<len(self._data):
            cx=self._centers[self._hover_index]
            c.create_rectangle(cx-slot*.48,top,cx+slot*.48,bottom,fill=COLORS['panel_alt'],outline='')
        grid=ma if mo else pa
        for v in grid.ticks():
            y=grid.position(v,top,bottom)
            c.create_line(left,y,xr,y,fill=COLORS['grid'] if v==0 else '#253348',width=1)
        if mo:
            self._text(left-8,12,ma.unit,anchor='e',size=8,bold=True,color=COLORS['muted'])
            for v in ma.ticks():self._text(left-8,ma.position(v,top,bottom),ma.label(v),anchor='e',color=COLORS['muted'])
        if po:
            self._text(xr+8,12,'Marže %',size=8,bold=True,color=COLORS['blue'])
            for v in pa.ticks():self._text(xr+8,pa.position(v,top,bottom),pa.label(v),color=COLORS['blue'])
        if self._enabled['revenue']:
            bw=max(2,min(42,slot*.54));zero=ma.position(0,top,bottom)
            for cx,row in zip(self._centers,self._data):
                v=series_value(row,'revenue')
                if v is None:continue
                y=ma.position(v,top,bottom)
                if abs(y-zero)<1:c.create_line(cx-bw/2,zero,cx+bw/2,zero,fill=COLORS['teal'],width=2)
                else:c.create_rectangle(cx-bw/2,min(y,zero),cx+bw/2,max(y,zero),fill=COLORS['teal'],outline='')
        for key,color,dash,scale in (('profit',COLORS['amber'],None,ma),('margin',COLORS['blue'],(5,3),pa)):
            if not self._enabled[key]:continue
            segments=[];points=[]
            for cx,row in zip(self._centers,self._data):
                v=series_value(row,key)
                if v is None:
                    if points:segments.append(points);points=[]
                else:points.extend((cx,scale.position(v,top,bottom)))
            if points:segments.append(points)
            for pts in segments:
                if len(pts)>=4:
                    # Straight segments hit every real value; no spline overshoot.
                    c.create_line(*pts,fill=color,width=2.5,dash=dash or (),joinstyle='round',capstyle='round')
                for i in range(0,len(pts),2):c.create_oval(pts[i]-2,pts[i+1]-2,pts[i]+2,pts[i+1]+2,fill=color,outline=COLORS['panel'])
        # Pixel-based thinning keeps 30-month histories readable at small widths.
        last_end=-100
        for i,(cx,row) in enumerate(zip(self._centers,self._data)):
            label=str(row.get('label',''));width=f.measure(label)
            if cx-width/2>=last_end+9 and cx+width/2<=w-3:
                self._text(cx,bottom+fh+5,label,anchor='center',color=COLORS['muted']);last_end=cx+width/2
        note='Chybějící data = mezera, nikoli nula.'
        if any(r.get('profit_complete') is False and r.get('profit_available') for r in self._data):note='* Zisk je částečný; marže jen tam, kde je podklad.'
        self._text(left,h-nh/2-3,note,width=w-left-3,size=8,color=COLORS['muted'])
        if self._hover_index is not None and self._hover_index<len(self._data):self._draw_tooltip(self._hover_index)

    def _draw_tooltip(self,index):
        r=self._data[index];lines=[str(r.get('full_label') or r.get('period') or r.get('label') or '')]
        for k,label,_ in self.SERIES:
            if self._enabled[k]:
                v=series_value(r,k);value=fmt_pct(v) if k=='margin' else fmt_money(v)
                lines.append(label+': '+value+(' *' if k=='profit' and r.get('profit_complete') is False and v is not None else ''))
        if r.get('source')=='legacy':lines.append('Zisk: historický měsíční souhrn')
        self._tooltip('\n'.join(lines),self._centers[index]+12,self._plot_bounds[1]+10)

    def _index_at(self,event):
        l,t,r,b=self._plot_bounds
        if not self._centers or not(l<=event.x<=r and t<=event.y<=b):return None
        return min(range(len(self._centers)),key=lambda i:abs(self._centers[i]-event.x))

    def _motion(self,event):
        index=self._index_at(event)
        if index!=self._hover_index:self._hover_index=index;self._draw()
        self.canvas.configure(cursor='hand2' if index is not None and self._on_period_click else 'arrow')

    def _leave(self,event=None):
        if self._hover_index is not None:self._hover_index=None;self._draw()

    def _click(self,event):
        index=self._index_at(event)
        if index is not None:self._notify(self._on_period_click,self._data[index])


class ShareChart(_CanvasFrame):
    PALETTE=PALETTE
    def __init__(self,master,rows,*,metrics,initial_metric,title_note='',max_items=6,
                 exclude_negative_from_shares=False,on_item_click=None,height=245):
        super().__init__(master)
        self.rows=[dict(x) for x in rows];self.metrics=metrics;self.max_items=max_items
        self._colors={}
        self.metric=initial_metric if any(x[0]==initial_metric for x in metrics) else metrics[0][0]
        self.view='shares';self.on_item_click=on_item_click;self._note=title_note;self._hit_regions=[];self._wedges=[]
        top=tk.Frame(self,bg=COLORS['panel']);top.pack(fill='x',pady=(0,5))
        self.metric_buttons={};self.view_buttons={}
        for key,label,_ in metrics:
            b=tk.Button(top,text=label,command=lambda k=key:self.set_metric(k),relief='flat',bd=0,padx=8,pady=5,font=('Calibri',9),state='normal' if self._metric_available(key) else 'disabled')
            b.pack(side='left',padx=(0,5));self.metric_buttons[key]=b
        views=tk.Frame(self,bg=COLORS['panel']);views.pack(fill='x',pady=(0,4))
        for key,label in (('shares','Podíly %'),('compare','Srovnání')):
            b=tk.Button(views,text=label,command=lambda k=key:self.set_view(k),relief='flat',bd=0,padx=8,pady=4,font=('Calibri',9))
            b.pack(side='left',padx=(0,5));self.view_buttons[key]=b
        self._refresh_buttons();self._canvas(height)
        self.canvas.bind('<Button-1>',self._click);self.canvas.bind('<Motion>',self._motion);self.canvas.bind('<Leave>',lambda e:self.canvas.delete('tooltip'))

    def _metric_available(self,key):return any(series_value(r,key) is not None for r in self.rows)
    def set_metric(self,key):
        if any(x[0]==key for x in self.metrics) and self._metric_available(key):self.metric=key;self._refresh_buttons();self._draw()
    def set_view(self,key):
        if key in ('shares','compare'):self.view=key;self._refresh_buttons();self._draw()
    def _refresh_buttons(self):
        for key,b in self.metric_buttons.items():b.configure(bg=COLORS['panel_alt'] if key==self.metric else COLORS['panel_soft'],fg=_metric_color(key) if key==self.metric else COLORS['muted'],disabledforeground=COLORS['muted'],activebackground=COLORS['border'])
        for key,b in self.view_buttons.items():b.configure(bg=COLORS['panel_alt'] if key==self.view else COLORS['panel_soft'],fg=COLORS['text'] if key==self.view else COLORS['muted'],activebackground=COLORS['border'])
    def _formatter(self):
        return {'count':count,'pct':fmt_pct}.get(next((x[2] for x in self.metrics if x[0]==self.metric),'money'),fmt_money)

    def _draw(self,event=None):
        c=self.canvas;c.delete('all');self._hit_regions=[];self._wedges=[]
        w=c.winfo_width();h=c.winfo_height()
        if w<180 or h<100:return
        items,missing,negative=grouped(self.rows,self.metric,self.max_items)
        if not items:
            self._text(w/2,h/2,'Pro zvolený ukazatel nejsou data.',width=w-15,anchor='center',color=COLORS['muted']);return
        self._colors=_display_colors(items)
        note=self._note
        if negative:note='Záporné hodnoty: používá se srovnání, nikoli koláč. '+note
        if missing:note+=f' Bez hodnoty: {missing}.'
        nf=self._font(8);nw=w-8
        # Measure the wrapped footnote, then reserve exactly that space.
        test=c.create_text(4,h-3,text=note,anchor='sw',width=nw,font=nf,tags=('labels',),fill=COLORS['muted'])
        nb=c.bbox(test);nh=(nb[3]-nb[1]+14) if note else 8
        required=(self._font(9).metrics('linespace')+7)*len(items)+nh+8
        if h<required and int(float(c.cget('height')))<required:c.configure(height=required)
        chart_h=h-nh
        if chart_h<70:c.delete(test);return
        fmt=self._formatter();total=sum(x['value'] for x in items)
        positive=not negative and total>0
        donut=self.view=='shares' and positive and w>=720
        start_x=12
        if donut:
            size=min(185,chart_h-12,w*.23);x0=12;y0=(chart_h-size)/2
            cx=x0+size/2;cy=y0+size/2;start=90
            for i,x in enumerate(items):
                if x['value']<=0:continue
                degrees=359.99*x['value']/total
                extent=-degrees
                # Tk může extrémně malý extent zaokrouhlit na 0 a vykreslit ho
                # jako celý kruh. Takový řez je pod rozlišovací schopností grafu,
                # proto zůstane v legendě/procentech, ale nekreslí se do donutu.
                if degrees>=MIN_DONUT_DEGREES:
                    c.create_arc(x0,y0,x0+size,y0+size,start=start,extent=extent,fill=self._colors.get(x['label'],'#8193A9'),outline=COLORS['panel'],width=2)
                    self._wedges.append((cx,cy,size/2,size*.30,start,extent,x,total))
                start+=extent
            hole=size*.62;c.create_oval(cx-hole/2,cy-hole/2,cx+hole/2,cy+hole/2,fill=COLORS['panel'],outline='')
            self._text(cx,cy-12,'CELKEM',anchor='center',size=8,color=COLORS['muted'])
            self._text(cx,cy+10,fmt(total),width=hole-6,anchor='center',size=10,bold=True)
            start_x=x0+size+28
        percent_on=self.view=='shares' and positive
        pw=65 if percent_on else 0
        value_width=max(110,max(self._font(9,True).measure(fmt(x['value'])) for x in items)+14)
        avail=w-start_x-value_width-pw-28
        # Sloupec názvů vychází z reálné délky textu, ne z poloviny šířky okna.
        # Na širokém monitoru tak nevzniká velká prázdná plocha před sloupci.
        label_need=max(self._font(9).measure(str(x['label'])) for x in items)+24
        label_cap=max(100,min(360,w*.34))
        label_width=max(70,min(label_cap,label_need));bar_left=start_x+label_width+14;bar_right=w-value_width-pw-16
        if bar_right-bar_left<35:
            label_width=max(30,bar_right-start_x-49);bar_left=start_x+label_width+14
        rowh=min(35,chart_h/max(1,len(items)))
        font_size=9 if rowh>=22 else 8
        self._compact=rowh<22
        # Both positive and negative amounts share a real signed horizontal axis.
        lo=min([0]+[x['value'] for x in items]);hi=max([0]+[x['value'] for x in items]);span=hi-lo or 1
        zero=bar_left+(0-lo)/span*max(0,bar_right-bar_left)
        for i,x in enumerate(items):
            y=rowh*(i+.5);col=COLORS['red'] if x['value']<0 else self._colors.get(x['label'],'#8193A9')
            c.create_oval(start_x,y-3,start_x+6,y+3,fill=col,outline='')
            self._text(start_x+13,y,x['label'],width=label_width-14,size=font_size)
            if bar_right>bar_left:
                c.create_line(bar_left,y,bar_right,y,fill=COLORS['panel_soft'],width=6)
                end=bar_left+(x['value']-lo)/span*(bar_right-bar_left)
                c.create_line(zero,y,end,y,fill=col,width=6)
                if negative:c.create_line(zero,y-6,zero,y+6,fill=COLORS['muted'])
            self._text(w-pw-12,y,fmt(x['value']),anchor='e',size=font_size,bold=True,color=col,width=value_width-6)
            if percent_on:self._text(w-5,y,fmt_pct(x['value']/total*100),anchor='e',size=font_size,color=COLORS['muted'])
            self._hit_regions.append((start_x,y-rowh/2,w,y+rowh/2,x,total if positive else None))

    def _item_at(self,event):
        for x0,y0,x1,y1,item,total in self._hit_regions:
            if x0<=event.x<=x1 and y0<=event.y<=y1:return item,total
        for cx,cy,outer,inner,start,extent,item,total in self._wedges:
            dx,dy=event.x-cx,cy-event.y;dist=math.hypot(dx,dy)
            angle=math.degrees(math.atan2(dy,dx))%360
            if inner<=dist<=outer and (start-angle)%360<=abs(extent):return item,total
        return None
    def _motion(self,event):
        hit=self._item_at(event);self.canvas.delete('tooltip')
        if hit:
            item,total=hit;text=item['label']+'\n'+self._formatter()(item['value'])
            if total:text+=' · '+fmt_pct(item['value']/total*100)
            self._tooltip(text,event.x+12,event.y+15)
        self.canvas.configure(cursor='hand2' if hit and hit[0]['source'] is not None and self.on_item_click else 'arrow')
    def _click(self,event):
        hit=self._item_at(event)
        if hit and hit[0]['source'] is not None:self._notify(self.on_item_click,hit[0]['source'])
