from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import tempfile
import time
import urllib.request
import zipfile
from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from .constants import APP_VERSION
from .release_safety import APP_ID, allowed_path, validate_folder


def _version_tuple(value):
    if not re.fullmatch(r'v?\d+\.\d+\.\d+', str(value).strip()):
        raise ValueError('Neplatná verze v aktualizačním manifestu.')
    return tuple(int(p) for p in str(value).strip().lstrip('v').split('.'))


def _updates_dir() -> Path:
    base = str(os.environ.get('LOCALAPPDATA', '')).strip()
    root = Path(base) if base else Path.home()/'AppData'/'Local'
    path = root/'TURTO'/'MesicniPrehledy'/'updates'
    path.mkdir(parents=True, exist_ok=True)
    return path


def check_update(manifest_url):
    if not manifest_url.strip():
        return {'configured': False, 'current': APP_VERSION}
    parts = urlsplit(manifest_url)
    if parts.scheme != 'https':
        raise ValueError('Aktualizační kanál musí používat HTTPS.')
    q = dict(parse_qsl(parts.query)); q['_turto_check'] = str(time.time_ns())
    url = urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(q), parts.fragment))
    req = urllib.request.Request(url, headers={'User-Agent': 'TURTO-Mesicni-Prehledy', 'Cache-Control': 'no-cache'})
    with urllib.request.urlopen(req, timeout=10) as r:
        data = json.loads(r.read(64*1024).decode('utf-8'))
    if data.get('app_id', APP_ID) != APP_ID:
        raise ValueError('Manifest patří jinému programu.')
    latest = str(data.get('version', '0.0.0'))

    # Od 1.0.3 preferujeme stejný model jako CRM: normální Inno Setup instalátor.
    # Nezávisíme už na samostatném PyInstaller helper EXE, který může blokovat WDAC/App Control.
    installer_url = str(data.get('installer_url') or '').strip()
    installer_sha = str(data.get('installer_sha256') or '').strip()
    use_installer = bool(installer_url and re.fullmatch(r'[0-9a-fA-F]{64}', installer_sha))
    payload_url = installer_url if use_installer else str(data.get('url', '') or '')
    payload_sha = installer_sha if use_installer else str(data.get('sha256', '') or '')
    return {
        'configured': True,
        'current': APP_VERSION,
        'latest': latest,
        'available': _version_tuple(latest) > _version_tuple(APP_VERSION),
        'url': payload_url,
        'sha256': payload_sha,
        'payload': 'installer' if use_installer else 'zip',
        'notes': data.get('notes', ''),
    }


def _download(url: str, sha256: str, target: Path) -> Path:
    if urlsplit(url).scheme != 'https':
        raise ValueError('Balíček musí být stažen přes HTTPS.')
    if not re.fullmatch(r'[0-9a-fA-F]{64}', sha256):
        raise ValueError('V manifestu chybí platný kontrolní součet. Aktualizace nebyla nainstalována.')
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(target.suffix + '.part')
    digest = hashlib.sha256(); size = 0
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'TURTO-Mesicni-Prehledy'})
        with urllib.request.urlopen(req, timeout=90) as r, temp.open('wb') as f:
            while chunk := r.read(256*1024):
                size += len(chunk)
                if size > 250*1024*1024:
                    raise ValueError('Aktualizační balíček je příliš velký.')
                digest.update(chunk); f.write(chunk)
        if digest.hexdigest().lower() != sha256.lower():
            raise ValueError('Kontrolní součet aktualizace nesouhlasí. Původní program zůstal beze změny.')
        os.replace(temp, target)
        return target
    finally:
        temp.unlink(missing_ok=True)


def prepare_update(download_url, sha256=''):
    path = urlsplit(download_url).path
    if path.lower().endswith('.exe'):
        name = Path(path).name or 'TURTO_Mesicni_Prehledy_Setup.exe'
        target = _download(download_url, sha256, _updates_dir()/name)
        with target.open('rb') as f:
            if f.read(2) != b'MZ':
                target.unlink(missing_ok=True)
                raise ValueError('Stažený instalátor není platný Windows EXE soubor.')
        return target

    # Kompatibilní fallback pro starší ZIP manifesty.
    temp = Path(tempfile.mkdtemp(prefix='turto_update_'))
    try:
        archive = _download(download_url, sha256, temp/'update.zip')
        target = temp/'package'; target.mkdir()
        with zipfile.ZipFile(archive) as z:
            infos = z.infolist()
            if len(infos) > 20000 or sum(x.file_size for x in infos) > 800*1024*1024:
                raise ValueError('Neočekávaná velikost rozbalené aktualizace.')
            for item in infos:
                if item.is_dir(): continue
                if not allowed_path(item.filename) or stat.S_ISLNK(item.external_attr >> 16):
                    raise ValueError('Balíček obsahuje nepovolenou cestu.')
            if z.testzip() is not None:
                raise ValueError('Aktualizační ZIP je poškozený.')
            z.extractall(target)
        spec = validate_folder(target)
        if _version_tuple(spec['version']) <= _version_tuple(APP_VERSION):
            raise ValueError('Balíček není novější než nainstalovaná verze.')
        return target
    except Exception:
        shutil.rmtree(temp, ignore_errors=True)
        raise


def launch_installer(package):
    p = Path(package)
    if p.is_file() and p.suffix.lower() == '.exe':
        # ShellExecute/os.startfile odpovídá běžnému dvojkliku na instalátor a
        # osvědčil se u TURTO CRM. Instalátor je per-user (PrivilegesRequired=lowest).
        try:
            os.startfile(str(p))
            return
        except OSError as exc:
            # Pokud podniková Application Control politika zakáže automatické
            # spuštění, necháme instalátor stažený a otevřeme jeho složku.
            try:
                subprocess.Popen(['explorer.exe', '/select,', str(p)])
            except Exception:
                pass
            code = getattr(exc, 'winerror', None)
            extra = f' (WinError {code})' if code is not None else ''
            raise RuntimeError(
                'Windows zablokoval automatické spuštění instalátoru'+extra+'.\n\n'
                'Instalátor už je bezpečně stažen zde:\n'+str(p)+'\n\n'
                'Spusťte jej ručně dvojklikem. Programová data zůstanou zachována.'
            ) from exc

    # Fallback pouze pro vývojové / starší zdrojové instalace.
    source = p
    installer = source/'update_installer.py'
    if installer.exists():
        import sys
        subprocess.Popen([sys.executable, str(installer), str(source), str(Path.cwd())], cwd=Path.cwd())
        return
    raise RuntimeError('Aktualizaci se nepodařilo spustit. Chybí instalátor.')
