from __future__ import annotations

import json
import os
import sys
from pathlib import Path

DEFAULT_CONFIG = {
    'database_path': 'data/turto_dashboard.db',
    'export_dir': 'exports',
    'import_archive_dir': 'imports',
    'backup_dir': 'backup',
    'update_manifest_url': 'https://raw.githubusercontent.com/jaroslavkucacz-code/TURTO-ZakazkyApp/mesicni-prehledy-stable/update_manifest.json',
    'theme': 'dark',
    'default_period': '2026-08',
}


def app_root() -> Path:
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]


def user_data_root() -> Path:
    override = str(os.environ.get('TURTO_REPORTING_DATA_ROOT', '')).strip()
    if override:
        root = Path(os.path.expandvars(os.path.expanduser(override)))
    else:
        local = str(os.environ.get('LOCALAPPDATA', '')).strip()
        if local:
            root = Path(local) / 'TURTO' / 'MesicniPrehledy'
        else:
            root = Path.home() / 'AppData' / 'Local' / 'TURTO' / 'MesicniPrehledy'
    root.mkdir(parents=True, exist_ok=True)
    return root.resolve()


def config_path() -> Path:
    return user_data_root() / 'config.json'


def load_config() -> dict:
    path = config_path()
    cfg = DEFAULT_CONFIG.copy()
    if path.exists():
        try:
            cfg.update(json.loads(path.read_text(encoding='utf-8')))
        except Exception:
            pass
    if not str(cfg.get('update_manifest_url','')).strip():
        cfg['update_manifest_url'] = DEFAULT_CONFIG['update_manifest_url']
    return cfg


def save_config(cfg: dict) -> None:
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding='utf-8')


def resolve_path(value: str) -> Path:
    p = Path(os.path.expandvars(os.path.expanduser(value)))
    if not p.is_absolute():
        p = user_data_root() / p
    return p.resolve()
