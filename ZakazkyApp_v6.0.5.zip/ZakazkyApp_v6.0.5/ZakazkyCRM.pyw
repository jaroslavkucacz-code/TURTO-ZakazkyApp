import app,crm_features,crm_runtime,crm_v605
crm_features.apply(app);crm_runtime.apply(app);crm_v605.apply(app)
app.cleanup_stale_test_session();app.ensure_schema();app.ensure_test_user();app.migrate_v41_visual_once();app.import_mail_contacts_v220_once();app.import_mail_contacts_v221_once();app.restore_people_from_v280_backup_once();app.post_import_cleanup_v222_once();app.App().mainloop()
